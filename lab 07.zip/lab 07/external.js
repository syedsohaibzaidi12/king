var number1, number2, res;
    	
    	function add(){
    		number1 = document.getElementById('num1').value;
    	    number2 = document.getElementById('num2').value;
    		result = parseInt(number1) +  parseInt(number2);
    		document.getElementById("res").value = result;
    	}
    	function sub(){
    		number1 = document.getElementById('num1').value;
    	    number2 = document.getElementById('num2').value;
    		result = number1 - number2;
    		document.getElementById("res").value = result;
    	}
    	function mul(){
    		number1 = document.getElementById('num1').value;
    	    number2 = document.getElementById('num2').value;
    		result = number1 * number2;
    		document.getElementById("res").value = result;
    	}
    	function divide(){
    		number1 = document.getElementById('num1').value;
    	    number2 = document.getElementById('num2').value;
    		result = number1 / number2;
    		document.getElementById("res").value = result;
    	}